#5 time table

n = input("What table would you like?")
for i in range(1,13) :
    print (i, "times", n, "=", i*n)
