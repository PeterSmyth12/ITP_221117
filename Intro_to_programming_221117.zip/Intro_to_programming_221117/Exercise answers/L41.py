# L4

i = 1
for j in range(5,61,5) :
    print (i, " times 5 =", j)
    i = i + 1
