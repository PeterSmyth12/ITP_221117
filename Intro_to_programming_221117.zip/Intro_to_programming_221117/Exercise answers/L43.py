#L4 3

while True :
    word = raw_input("Give me a word >")
    if word == "End" :
        break
    print (word)
