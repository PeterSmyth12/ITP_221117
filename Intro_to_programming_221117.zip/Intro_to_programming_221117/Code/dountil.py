# do ... until

while True :
    num = input("Give me a number >")
    print (num)
    if num == 0 :
        break
