print ("\nExample 1\n")

inputvalue = input("give me a number ")

print(type(inputvalue))

int_inputvalue = int(inputvalue)

print(type(int_inputvalue))

print ("\nExample 2\n")

inputvalue = input("give me a number ")

print(type(inputvalue))

int_inputvalue = float(inputvalue)

print(type(int_inputvalue))


print ("\nExample 3\n")

inputvalue = raw_input("give me a number ")

print(type(inputvalue))

int_inputvalue = int(inputvalue)

print(type(int_inputvalue))

