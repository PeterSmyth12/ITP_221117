# while loop
n = 10
sum = 0
# sum of n  numbers
i = 1
while  i <= 10 :
    sum = sum + i
    i = i + 1
print ("The sum of the numbers from 1 to", n, "is ", sum)
