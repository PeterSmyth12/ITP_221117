# If ... Elif ... Else ... EndIf

a = 2
b = 4
print (a,b)

if a > b :
    print (a, " is greater than ", b)
elif a == b :
    print (a, " equals ", b)
else :
    print (a, " is less than ", b)

    
