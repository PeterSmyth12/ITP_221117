a = 3
print (a)
b = 6.2
print (a,b)
c = "Hello World"
print (c)
print (a, c, b)
print (a+b)

d = "to Peter"
print (c,d)
print (c + d)

