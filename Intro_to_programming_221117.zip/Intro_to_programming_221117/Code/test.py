print("hello\nworld")
