# If ... Else ... EndIf

a = 4
b = 5
print (a,b)

if a > b :
    print (a, " is greater than ", b)
else :
    print (a, " is NOT greater than ", b)


