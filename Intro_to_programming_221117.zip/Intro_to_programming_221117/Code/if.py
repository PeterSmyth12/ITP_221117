# if .. End If

print ("\nExample 1\n")

a= 5
b= 4
print ("a is", a, "b is",b)
if a > b :
    print (a, "is bigger than ", b)

print ("\nExample 2\n")

a= 3
b= 4
print ("a is", a, "b is",b)
if a > b :
    print (a , "is bigger than ", b)

print ("\nExample 3\n")

a= 4
b= 4
print ("a is", a, "b is",b)
if a == b :
    print (a, "is equal to", b)


    
    

    
