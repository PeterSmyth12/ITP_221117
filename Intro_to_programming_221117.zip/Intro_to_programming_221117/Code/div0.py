# simple div by 0

x = 6

y =0
print (x/y)


#  div by 0 when i gets down to 6
#for i in range(10, 0 , -1) :
#    k = i**3
#    l = k / (i - 6)
#    print i, 10/i



